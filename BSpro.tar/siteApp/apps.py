﻿from django.apps import AppConfig


class SiteAppConfig(AppConfig):
    name = 'siteApp'
