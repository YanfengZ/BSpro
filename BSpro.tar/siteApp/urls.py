﻿from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index, name=''),			
    url(r'^choose_set/$', views.choose_set, name='choose_set'),#背单词	
    url(r'^login/$', views.login, name='login'),#登陆 					
    url(r'^signup/$', views.signup, name='signup'),#注册				
    url(r'^review/$', views.review, name='review'),#					
    url(r'^index_after/$', views.index_after, name='index_after'),#				
    url(r'^study/$', views.study, name='study'),#记忆单词中				
    url(r'^study_six/$', views.study_six, name='study_six'),#			
    url(r'^study_toefl/$', views.study_toefl, name='study_toefl'),#		
    url(r'^note/$', views.note, name='note'),#单词本					
    url(r'^review_four/$', views.review_four, name='review_four'),#复习	
    url(r'^review_six/$', views.review_six, name='review_six'),#		
    url(r'^review_toefl/$', views.review_toefl, name='review_toefl'),#	 
]