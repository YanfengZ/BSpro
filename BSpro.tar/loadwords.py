﻿from siteApp.models import Cet4  

a = Cet4.objects.all()
b = a.delete()
count = 0

with open("./words/Cet4.txt",'r',encoding='utf-8') as f:  
    for line in f:  
        vocabulary, paraphrase = line.split('***')  
        Cet4.objects.create(word=vocabulary, paraphrases=paraphrase, id_num=count)
        count = count + 1


from siteApp.models import Cet6  

a = Cet6.objects.all()
b = a.delete()
count = 0

with open("./words/Cet6.txt",'r',encoding='utf-8') as f:  
    for line in f:  
        vocabulary, paraphrase = line.split('***')  
        Cet6.objects.create(word=vocabulary, paraphrases=paraphrase, id_num=count)
        count = count + 1

from siteApp.models import Toefl  

a = Toefl.objects.all()
b = a.delete()
count = 0

with open("./words/Toefl.txt",'r',encoding='utf-8') as f:  
    for line in f:  
        vocabulary, paraphrase = line.split('***')  
        Toefl.objects.create(word=vocabulary, paraphrases=paraphrase, id_num=count)
        count = count + 1 
